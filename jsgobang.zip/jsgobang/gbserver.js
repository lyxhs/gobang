const express = require('express')
const SocketServer = require('ws').Server
const PORT = 7983 //指定 port

const server = express().listen(PORT, () => {
    console.log(`Listening on ${PORT}`)
});

var player = new Array();
var onlineplayer = new Array();
var matching = new Array();


const wss = new SocketServer({ server })//搭建服务器
wss.on("connection", (ws, req) => {
    let Invitee = null;
    let byinvitee = null;
    var name = "";
    var where = 0;
    var id = 0;
    var another = 0;
    var nowstate = true; //true为空闲
    var ourwhere;
    var ismatch = false;
    ws.on("message", message => {
        var get = message.toString();
        console.log(get);
        if (get.includes("&^^&`")) {
            wss.clients.forEach(s => {
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("usersend`" + get.split("`")[1])
                }
            })
        } else if (get.includes("#")) {
            name = get.split(",")[1]
            var have = false;
            for (var i = 0; i < player.length; i++) {
                console.log(player[i]);
                if (player[i].split("&&")[0] == name) {
                    ws.send("false")
                    have = true;
                    break;
                }
            }
            if (!have) {
                ws.send("true");
            }
        } else if (get.includes("&&,")) {
            var key = get.split(",")[1];
            id = gid();
            player[player.length] = name + "&&" + key + "&&" + id;
            onlineplayer.push(id);
            ws.socketIdxos = id;
            where = onlineplayer.length - 1;
            ws.send("!ok," + id)
        } else if (get.includes("$$&,")) {
            ismathch = false;
            var find = false;
            ws.socketIdxos = id;
            another = get.split(",")[1]
            wss.clients.forEach(s => {
                console.log(s.socketIdxos);
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    find = true;
                    console.log("find");
                    s.send(id + "*@#$*一名玩家向你发起了邀请……对方玩家名：" + name + ",id:" + id);
                }
            })
            if (!find) {
                another = 0;
                ws.send("!@,没有找到指定用户")
            }
        } else if (get.includes("$%&&ok,")) {
            nowstate = false
            another = get.split(",")[1];
            wss.clients.forEach(s => {
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("!@y&,对方同意了你的请求，按确定即开始游戏");
                }
            })
        } else if (get.includes("$%&&no,")) {
            nowstate = true;
            another = 0;
            wss.clients.forEach(s => {
                if (s.socketIdxos == get.split(",")[1] && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("!@n&,对方拒绝了你的请求");
                }
            })
        } else if (get == "anotherok") {
            nowstate = false;
            console.log(id + "与" + another + "搭建房间成功!")
            wss.clients.forEach(s => {
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("gamebegining");
                }
            })
            ws.send("gamebegining")
        } else if (get == "anothernook") {
            nowstate = true;
            another = 0;
        } else if (get.includes("%$%&,")) {
            wss.clients.forEach(s => {
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("%*&," + get.split(",")[1]);
                }
            })
        } else if (get == "$@&%win") {
            ws.send("youwin")
            nowstate = true
            wss.clients.forEach(s => {
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("youlost");
                }
            })
            another = 0;
        } else if (get.includes("%@!")) {
            var getname = get.split("!")[1];
            var findname = false;
            for (var i = 0; i < player.length; i++) {
                if (getname == player[i].split("&&")[0]) {
                    findname = true;
                    ws.send("findyourname")
                    ourwhere = i;
                    break;
                }
            }
            if (!findname) {
                ws.send("notfind")
            }

        } else if (get.includes("^!@,")) {
            var getkey = get.split(",")[1]
            var isok = false;
            if (getkey == player[ourwhere].split("&&")[1]) {
                isok = true;
                for (var i = 0; i < onlineplayer.length; i++) {
                    if (onlineplayer[i] == player[ourwhere].split("&&")[2]) {
                        isok = false;
                        break;
                    }
                }
                if (isok) {
                    id = player[ourwhere].split("&&")[2]
                    onlineplayer.push(id)
                    ws.send("$id:" + player[ourwhere].split("&&")[2])
                } else {
                    ws.send("thenamehavebeuse");
                }
            } else {
                ws.send("That'snot~")
            }
        } else if (get.includes("cut!!,")) {
            if (parseInt(get.split(",")[1]) < where) {
                where = where - 1;
            }
        } else if (get == "leave") {
            another = 0;
        } else if (get == "lost") {
            another = 0;
        } else if (get == "beginsuiji") {
            ismatch = true;
            nowstate = true;
            wss.clients.forEach(s => {
                if (s.socketIdxos != id) {
                    s.send("newplayeradd," + id)
                }

            })
        } else if (get.includes("newplayeradd,")) {
            if (ismatch) {
                if (nowstate) {
                    nowstate = false;
                    another = parseInt(get.split(",")[1]);
                    wss.clients.forEach(s => {
                        if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                            s.send("youmatch," + id);
                        }
                    })
                    ws.send("matchpeople," + another)
                }
            }
        } else if (get.includes("youmatch,")) {
            if (ismatch) {
                if (nowstate) {
                    another = parseInt(get.split(",")[1]);
                    ws.send("youhavematchpeople," + another)
                }
            }
        } else if (get == "qvxiaolianji") {
            ismatch = false;
            nowstate = true;
            another = 0;
            ws.send("havebeenqx")
        } else if (get == "touxiang") {
            nowstate = true;
            wss.clients.forEach(s => {
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("wotouxiangle")
                }
            })
            another = 0;
        } else if (get == "bierentx") {
            nowstate = true;
            another = 0;
        }
    })

    ws.on('close', close => {
        if (id != 0) {
            onlineplayer.splice(where, 1);
            wss.clients.forEach(s => {
                s.send("cut!!," + where);
            })
        }
        if (another != 0) {
            wss.clients.forEach(s => {
                if (s.socketIdxos == another && s.readyState == 1 && s.socketIdxos != id) {
                    s.send("leave")
                }
            })
        }
    })
})


function gid() {
    var id = Math.floor(Math.random() * (99999999 - 10000000 + 1)) + 10000000
    var have = false;
    for (var i = 0; i < player.length; i++) {
        if (player[i].split("&&")[2] == id.toString()) {
            have = true;
            break;
        }
    }
    if (have) {
        gid();
    } else {
        return id;
    }
}